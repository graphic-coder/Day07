package 반복문;

import java.util.Iterator;

public class For문연습2 {

	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.print("★");
		}
		System.out.println();
		
		for (int i = 0; i < 5; i++) {
			System.out.print("커피");
		}
		System.out.println();
		
		for (int i = 0; i < 3; i++) {
			System.out.print("커피우유");
		}
		System.out.println();
		
		for (int i = 0; i < 3; i++) {
			System.out.println((i + 1) + ": 짱");
		}
	}

}
