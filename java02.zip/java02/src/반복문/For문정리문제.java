package 반복문;

public class For문정리문제 {

	public static void main(String[] args) {
		//#1. 33~222
		int sum = 0;
		for (int i = 33; i <= 222; i++) {
			sum = sum + i;
		// 33  = 0 + 33
		// 67  = 33 + 34
		// 102 = 67 + 35
		}
		System.out.println(sum);
		System.out.println("----------");
		
		//2. 55~4500, 2씩 점프
		int sum1 = 0;
		for (int i = 55; i <= 4500; i = i + 2) {
			sum1 = sum1 + i;
		}
		System.out.println(sum1);
		System.out.println("----------");
		
		//3. 0~6000, 5씩 점프
		int sum2 = 0;
		for (int i = 0; i <= 6000; i = i + 5) {
			sum2 = sum2 + i;
		}
		System.out.println(sum2);
	}

}
