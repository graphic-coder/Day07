package 조건문;

import javax.swing.JOptionPane;

public class 조건문확인문제 {

	public static void main(String[] args) {
		// #1
		String pw = JOptionPane.showInputDialog("암호를 대시오.");

		if (pw.equals("pass")) {
			System.out.println("들어오세요.");
		} else {
			System.out.println("나가세요.");
		}
	}

}