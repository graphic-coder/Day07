package 조건문;

import javax.swing.JOptionPane;

public class 조건문확인문제2 {

	public static void main(String[] args) {
		// #3
		String food = JOptionPane.showInputDialog("당신이 먹고 싶은 점심 메뉴는 1)짜장면, 2)라면, 3)회");
		switch (food) {
		case "짜장면":
			System.out.println("중국집으로 가요!");
			break;
		case "라면":
			System.out.println("분식집으로 가요!");
			break;
		case "회":
			System.out.println("횟집으로 가요!");
			break;
		default:
			System.out.println("그냥 안 먹어요!");
			break;
		}
	}

}
